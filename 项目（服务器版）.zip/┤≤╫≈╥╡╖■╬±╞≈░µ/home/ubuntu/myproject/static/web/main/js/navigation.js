//
// var dropdownbtn = document.getElementById('dropdownbtn');
// var dropdownli = document.getElementById('dropdownul').getElementsByTagName('li');
// dropdownli[0].addEventListener('click', function () {
//     dropdownbtn.innerHTML = '书籍';
//     console.log(0)
// })
// dropdownli[1].addEventListener('click', function () {
//     dropdownbtn.innerHTML = '影视';
//     console.log(1)
// })
// dropdownli[2].addEventListener('click', function () {
//     dropdownbtn.innerHTML = '小组';
//     console.log(2)
// })
// dropdownli[3].addEventListener('click', function () {
//     dropdownbtn.innerHTML = '话题';
//     console.log(3)
// })