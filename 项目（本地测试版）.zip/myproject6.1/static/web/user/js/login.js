function parse_data(){
    let $password_input = $("#password");
    let password = $password_input.val().trim();
    $password_input.val(md5(password));
    return true
}
addEventListener("load", function() {
    setTimeout(hideURLbar, 0);
}, false);

function hideURLbar() {
    window.scrollTo(0, 1);
}
var	user = document.getElementById('username');
var pwd = document.getElementById('password');
var wrong = document.getElementById('wrong');
var eyeFlag = 0;
var btn = document.getElementById('submit')
var eye = document.getElementById('eye');
/*function strCheck(str){
    if(str.length>=6&&str.length<=16){
        return !!/([a-zA-Z]+[0-9]+|[0-9]+[a-zA-Z])/.exec(str);
    }else{
      return false;
    }
}*/
eye.addEventListener('click', function () {
    console.log("2");
    if(eyeFlag === 0){
        pwd.type = 'text';
        eyeFlag = 1;
        eye.className = "glyphicon glyphicon-eye-open";
    }
    else{
        pwd.type = 'password';
        eyeFlag = 0;
        eye.className = "glyphicon glyphicon-eye-close";
    }
});

btn.addEventListener('click', function (event) {
    if(user.value.length === 0 ){
        wrong.className = "wrongText";
        wrong.innerHTML = '请输入用户名';
        event.preventDefault();
    }
    /*else if(!strCheck(pwd.value)){
        wrong.className = "wrongText";
        wrong.innerHTML = '密码长度必须为6~16位，且必须包含数字和字母';
        event.preventDefault();
    }*/
});

