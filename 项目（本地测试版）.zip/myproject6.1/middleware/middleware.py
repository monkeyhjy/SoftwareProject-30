from django.http import JsonResponse
from django.shortcuts import redirect
from django.urls import reverse
from django.utils.deprecation import MiddlewareMixin

from Web.models import User

REQUIRE_LOGIN_JSON = [
    '/web/checkuser1/',
    '/web/addgroup/',
    '/web/dealcomment/',
    '/web/deletecomment/',
    '/web/movie_deal_comment/',
    '/web/movie_delete_comment/',
]
# 写路径
REQUIRE_LOGIN = [
    '/web/booktip/',
    '/web/bookscore/',
    '/web/comment/',
    '/web/movie_tip/',
    '/web/movie_score/',
    '/web/movie_comment/',
    '/web/onegroup/',
    '/web/mygroup/',
    '/web/groupcommentresponse/',
    '/web/topic_mine/',
    '/web/topic_one/',
    '/web/topic_join/',
]


class LoginMiddleware(MiddlewareMixin):
    def process_exception(self, request, exception):
        print(request, exception)
        # return redirect(reverse('web:main'))

    def process_request(self, request):
        user_id = request.session.get('user_id')
        if user_id:
            request.user = User.objects.get(pk=user_id)

        if request.path in REQUIRE_LOGIN_JSON:

            user_id = request.session.get('user_id')

            if user_id:
                try:
                    user = User.objects.get(pk=user_id)

                    request.user = user
                except:
                    # return redirect(reverse('axf:login'))
                    data = {
                        'status': 302,
                        'msg': 'user not avaliable'
                    }

                    return JsonResponse(data=data)
            else:
                # return redirect(reverse('axf:login'))
                data = {
                    'status': 302,
                    'msg': 'user not login',
                }

                return JsonResponse(data=data)

        if request.path in REQUIRE_LOGIN:
            user_id = request.session.get('user_id')

            if user_id:
                try:
                    user = User.objects.get(pk=user_id)

                    request.user = user
                except:
                    return redirect(reverse('web:login'))

            else:
                return redirect(reverse('web:login'))
