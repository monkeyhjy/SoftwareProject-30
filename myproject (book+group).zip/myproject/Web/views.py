import decimal
import uuid
from decimal import Decimal
from itertools import chain

from django.contrib.auth.hashers import make_password, check_password
from django.core.cache import cache
from django.core.paginator import Paginator
from django.db.models import Q, Avg
from django.http import HttpResponse, JsonResponse, HttpResponseRedirect
from django.shortcuts import render, redirect
from django.urls import reverse

from Web.models import *

# Create your views here.
# 服务器测试
from Web.views_constant import *
from Web.views_helper import send_email_activate
from myproject.settings import MEDIA_KEY_PREFIX


def index(request):
    return HttpResponse('index')


def main(request):
    # user_id = request.session.get('user_id')
    data = {"title": "主页",
            'books': Book.objects.all().order_by('-b_score')[:7],
            'book_comments': Book_comment.objects.all().order_by('-agree_num')[:4]}
    # if user_id:
    #     user = User.objects.get(pk=user_id)
    #     data['is_login'] = True
    #     data['username'] = user.u_username
    #     data['is_manager'] = user.is_manager
    #     if user.u_icon != "":
    #         data['icon'] = MEDIA_KEY_PREFIX + user.u_icon.url
    #     else:
    #         data['icon'] = '#'

    return render(request, 'main/mainpage.html', context=data)


def register(request):
    if request.method == 'GET':

        data = {
            "title": "注册",
        }

        return render(request, 'user/register.html', context=data)

    elif request.method == 'POST':

        username = request.POST.get("username")
        email = request.POST.get("email")
        password = request.POST.get("password")
        icon = request.FILES.get("icon")
        if icon == None:
            icon = "suoluetubig.jpg"

        # user = User.objects.filter(u_email=email)
        # if user.exists():
        #     return redirect(reverse("Web:register"))

        # password = hash_str(password)
        password = make_password(password)

        user = User()
        user.u_username = username
        user.u_email = email
        user.u_password = password
        user.u_icon = icon

        user.save()

        u_token = uuid.uuid4().hex

        print(u_token)

        cache.set(u_token, user.id, timeout=60 * 60 * 24)

        send_email_activate(username, email, u_token)

        return redirect(reverse('web:login'))


def login(request):
    user_id = request.session.get('user_id')
    if user_id:
        return redirect(reverse('web:main'))
        # return HttpResponseRedirect(reverse('web:one_group',args=[7]))
    else:
        if request.method == "GET":
            error_message = request.session.get('error_message')
            data = {
                "title": "登录",
            }
            if error_message:
                del request.session['error_message']
                data['error_message'] = error_message
            return render(request, 'user/login.html', context=data)
        elif request.method == "POST":

            username = request.POST.get("username")
            password = request.POST.get("password")

            users = User.objects.filter(u_username=username)
            if users.exists():
                user = users.first()
                if check_password(password, user.u_password):
                    if user.is_active:
                        request.session['user_id'] = user.id
                        request.session['user_name'] = user.u_username
                        request.session['is_manager'] = user.is_manager
                        return redirect(reverse('web:main'))
                    else:
                        print('用户未激活')
                        request.session['error_message'] = '用户未激活'
                        return redirect(reverse('web:login'))
                else:
                    print('密码错误')
                    request.session['error_message'] = '密码错误'
                    return redirect(reverse('web:login'))
            print('用户名不存在')
            request.session['error_message'] = '用户不存在'
            return redirect(reverse('web:login'))
        else:
            return redirect(reverse('web:login'))


def activate(request):
    u_token = request.GET.get('u_token')

    user_id = cache.get(u_token)

    print(user_id)

    if user_id:
        cache.delete(u_token)

        user = User.objects.get(pk=user_id)

        user.is_active = True

        user.save()

        return redirect(reverse('web:login'))

    return render(request, 'user/activate_fail.html')


def check_user(request):
    username = request.GET.get("username")
    users = User.objects.filter(u_username=username)
    data = {
        "status": HTTP_OK,
        "msg": 'username can use',
    }

    if users.exists():
        data['status'] = HTTP_USER_EXIST
        data['msg'] = 'user already exist'
    else:
        email = request.GET.get('email')
        users_email = User.objects.filter(u_email=email)
        if users_email.exists():
            data['status'] = HTTP_EMAIL_EXIST
            data['msg'] = 'email already exist'

    return JsonResponse(data=data)


def logout(request):
    request.session.flush()
    return redirect(reverse('web:login'))


def book_mainpage(request):
    data = {
        "title": "书籍主页",
    }
    books = Book.objects.all()[:3]
    data['books'] = books
    data['books1'] = Book.objects.filter(b_tag="经典名著")
    data['books2'] = Book.objects.filter(b_tag="长篇小说")
    data['books3'] = Book.objects.filter(b_tag="散文集")
    data['books4'] = Book.objects.filter(b_tag="言情小说")
    data['book_comments'] = Book_comment.objects.all().order_by('-agree_num')[:8]
    return render(request, 'book/bookmainpage.html', context=data)


def movie_mainpage(request):
    data = {
        "title": "电影主页",
    }
    return render(request, 'movie/moviemainpage.html', context=data)


def only_one_book(request, book_id):
    book = Book.objects.get(pk=book_id)
    user_id = request.session.get('user_id')
    data = {'title': book.b_book_name, 'book': book}
    relative_bookss = Book.objects.filter(b_tag=book.b_tag)
    relative_books = []
    relative_books.extend(relative_bookss)
    relative_books.remove(book)
    data['relative_books'] = relative_books
    is_score = Book_score.objects.filter(book_id=book_id).filter(user_id=user_id)
    comments = Book_comment.objects.filter(book_id=book_id).order_by('-agree_num')
    page = int(request.GET.get("page", 1))

    paginator = Paginator(comments, 4)

    page_object = paginator.page(page)

    data['comments'] = page_object

    data["page_range"] = paginator.page_range

    if is_score.exists():
        data['score'] = is_score.first().score

    return render(request, 'book/onlyonebook.html', context=data)


def group_main_page(request):
    data = {
        "title": "小组主页",
    }
    groups = Group.objects.all().order_by('-g_num')[:9]
    data['groups'] = groups
    return render(request, 'group/groupmainpage.html', context=data)


def only_one_group(request, group_id):
    group = Group.objects.get(pk=group_id)
    user_id = request.session.get('user_id')
    members = []
    member1 = Group_relations.objects.filter(g_group_id=group_id).filter(g_level__gte=3)
    member2 = Group_relations.objects.filter(g_group_id=group_id).filter(g_level=2)
    member3 = Group_relations.objects.filter(g_group_id=group_id).filter(g_level=1)
    members.extend(member1)
    members.extend(member2)
    members.extend(member3)
    comments = []
    comment1 = Group_comment.objects.filter(group_id=group_id).filter(is_essential=True).filter(is_top=True)
    comment2 = Group_comment.objects.filter(group_id=group_id).filter(is_essential=False).filter(is_top=True)
    comment3 = Group_comment.objects.filter(group_id=group_id).filter(is_essential=True).filter(is_top=False)
    comment4 = Group_comment.objects.filter(group_id=group_id).filter(is_essential=False).filter(is_top=False)
    comments.extend(comment1)
    comments.extend(comment2)
    comments.extend(comment3)
    comments.extend(comment4)

    data = {
        "title": group.g_name,
        "members": members,
    }
    page = int(request.GET.get("page", 1))

    paginator = Paginator(comments, 4)

    page_object = paginator.page(page)

    data['comments'] = page_object

    data["page_range"] = paginator.page_range
    if user_id:
        user = User.objects.get(pk=user_id)
        data['user'] = user
        group_relation = Group_relations.objects.filter(g_group_id=group_id).filter(g_user_id=user_id)
        # print(group_relation.first().g_level)
        if group_relation.exists():
            data['level'] = group_relation.first().g_level
        else:
            data['level'] = 0
        group_add = Add_group.objects.filter(g_group_id=group_id).filter(g_user_id=user_id)
        if group_add.exists():
            data['is_apply'] = True
            if group_add.first().is_admin:
                data['is_applyadmin'] = True
            else:
                data['is_applyadmin'] = False
        else:
            data['is_apply'] = False
            data['is_applyadmin'] = False
    else:
        data['level'] = 0
        data['is_apply'] = False
    data['group'] = group
    if request.method == 'POST':
        if data['is_apply'] == False:
            add_group = Add_group()
            add_group.g_group = Group.objects.get(pk=group_id)
            add_group.g_user = user
            add_group.reason = request.POST.get('reason')
            if data['level'] == 0:
                add_group.is_admin = False
            elif data['level'] == 1:
                add_group.is_admin = True
                data['is_applyadmin'] = True
            add_group.save()
            data['is_apply'] = True
    return render(request, 'group/one_group.html', context=data)


def my_group(request):
    user_id = request.session.get('user_id')
    if not user_id:
        return redirect(reverse('web:login'))
    else:
        data = {
            "title": '我的小组',
        }

    mygroups = Group.objects.filter(group_relations__g_user=user_id).order_by('-g_num')

    page = int(request.GET.get("page", 1))

    # per_page = int(request.GET.get("per_page", 8))

    paginator = Paginator(mygroups, 8)

    page_object = paginator.page(page)

    data['mygroups'] = page_object

    data["page_range"] = paginator.page_range

    # print(page_object)
    #
    # print(paginator.page_range)

    return render(request, 'group/groupmine.html', context=data)


def check_user1(request):
    data = {
        'status': 200,
        'msg': 'login in'
    }

    return JsonResponse(data=data)


def group_search(request):
    data = {
        "title": "小组搜索",
    }
    content = ""
    if request.method == 'POST':
        content = request.POST.get('search_content')
    elif request.method == 'GET':
        content = request.GET.get('search_content')
    group1 = Group.objects.filter(g_id=content)
    group2 = Group.objects.filter(Q(g_name__icontains=content) | Q(g_describe__icontains=content))
    groups = []
    groups.extend(group1)
    groups.extend(group2)
    groups = list(set(groups))
    page = int(request.GET.get("page", 1))
    paginator = Paginator(groups, 8)
    page_object = paginator.page(page)
    data['groups'] = page_object
    data['search_content'] = content
    data["page_range"] = paginator.page_range
    return render(request, 'group/groupsearch.html', context=data)


def group_deal_request(request, group_id):
    user_id = request.session.get('user_id')
    data = {
        "title": "申请管理",
    }
    # if user_id:
    #     user = User.objects.get(pk=user_id)
    #     data['is_login'] = True
    #     data['username'] = user.u_username
    #     data['is_manager'] = user.is_manager
    #     if user.u_icon != "":
    #         data['icon'] = MEDIA_KEY_PREFIX + user.u_icon.url
    #     else:
    #         data['icon'] = '#'
    power = Group_relations.objects.filter(g_group_id=group_id).filter(g_user_id=user_id)
    if power.exists() and power.first().g_level >= 2:
        add_request = []
        add_request1 = Add_group.objects.filter(g_group_id=group_id).filter(is_admin=False)
        add_request.extend(add_request1)
        if power.first().g_level >= 3:
            add_request2 = Add_group.objects.filter(g_group_id=group_id).filter(is_admin=True)
            add_request.extend(add_request2)
        page = int(request.GET.get("page", 1))
        paginator = Paginator(add_request, 8)
        page_object = paginator.page(page)
        data['requests'] = page_object
        data["page_range"] = paginator.page_range
        data['groupid'] = group_id
        return render(request, 'group/groupdealrequest.html', context=data)
    else:
        return render(request, 'group/groupmainpage.html', context=data)


def add_group(request):
    applyid = request.GET.get('applyid')
    apply = Add_group.objects.get(pk=applyid)
    if request.GET.get('type') == 'agree':
        if apply.is_admin:
            relations = Group_relations.objects.filter(g_group_id=apply.g_group.id).filter(g_user=apply.g_user)
            if relations.exists():
                relation = relations.first()
                relation.g_level = 2
                relation.save()
            # print(relation.g_level)
        else:
            group_relation = Group_relations()
            group_relation.g_level = 1
            group_relation.g_group = apply.g_group
            group_relation.g_user = apply.g_user

            group_relation.save()
            group = Group.objects.get(pk=apply.g_group.id)
            group.g_num = group.g_num + 1
            group.save()
        data = {
            "msg": "add success",
            "groupid": apply.g_group.id,
        }
    else:
        data = {
            "msg": "refuse success",
            "groupid": apply.g_group.id,
        }
    apply.delete()
    return JsonResponse(data=data)


def group_create(request):
    data = {
        'title': '小组创建',
    }
    if request.method == 'GET':
        return render(request, 'group/groupcreate.html', context=data)
    elif request.method == 'POST':
        group = Group()
        group.g_id = request.POST.get('group_id')
        group.g_name = request.POST.get('group_name')
        group.g_describe = request.POST.get('message')
        group.g_num = 1
        group.save()
        group_relation = Group_relations()
        group_relation.g_user_id = request.session.get('user_id')
        group_relation.g_group = group
        group_relation.g_level = 3
        group_relation.save()
        return redirect(reverse('web:one_group', args={group.id}))


def group_post(request, group_id):
    user_id = request.session.get('user_id')
    user = User.objects.get(pk=user_id)
    group_relation = Group_relations.objects.filter(g_group_id=group_id).filter(g_user_id=user_id)
    if not user_id:
        return redirect(reverse('web:one_group', args={group_id}))
    elif not group_relation.exists():
        return redirect(reverse('web:one_group', args={group_id}))
    data = {"title": "发帖主页", "group_id": group_id}
    if request.method == 'POST':
        g_comment = Group_comment()
        g_comment.title = request.POST.get('title')
        g_comment.content = request.POST.get('content')
        g_comment.picture = request.FILES.get("picture")
        g_comment.group_id = group_id
        g_comment.user = user
        g_comment.save()
        return redirect(reverse('web:one_group', args={group_id}))
    return render(request, 'group/grouppost.html', context=data)


def check_group(request):
    group_id = request.GET.get('group_id')
    group = Group.objects.filter(g_id=group_id)
    if group.exists():
        data = {
            'status': 900,
            'msg': 'g_id exist',
        }
    else:
        data = {
            'status': 200,
            'msg': 'ok',
        }
    return JsonResponse(data=data)


def book_search(request):
    data = {
        "title": "书籍搜索",
    }
    content = ""
    if request.method == 'POST':
        content = request.POST.get('search_content')
    elif request.method == 'GET':
        content = request.GET.get('search_content')
    books = []
    if content.isdigit():
        book0 = Book.objects.filter(b_year=content)
        books.extend(book0)
    book1 = Book.objects.filter(b_book_name__icontains=content)
    book2 = Book.objects.filter(Q(b_author=content) | Q(b_tag=content) | Q(b_publish=content))
    book3 = Book.objects.filter(Q(b_book_describe__icontains=content) | Q(b_author_describe__icontains=content))
    books.extend(book1)
    books.extend(book2)
    books.extend(book3)
    books = list(set(books))
    page = int(request.GET.get("page", 1))
    paginator = Paginator(books, 8)
    page_object = paginator.page(page)
    data['books'] = page_object
    data['search_content'] = content
    data["page_range"] = paginator.page_range
    return render(request, 'book/booksearch.html', context=data)


def topic_main_page(request):
    data = {'title': '话题主页'}
    return render(request, 'topic/topicmainpage.html', context=data)


def book_tip(request):
    data = {'title': '举报页面'}
    comment_id = request.GET.get('comment_id')
    comment = Book_comment.objects.get(pk=comment_id)
    data['book_id'] = comment.book.id
    data['comment_id'] = comment_id
    if request.method == 'POST':
        tip = Book_comment_tip()
        tip.comment = comment
        tip.user = request.user
        tip.title = request.POST.get('tip_title')
        tip.reason = request.POST.get('message')
        tip.save()
        comment.is_report = True
        comment.save()
        return redirect(reverse('web:one_book', args={comment.book.id}))
    else:
        return render(request, 'book/booktip.html', context=data)


def book_score(request):
    book_id = request.GET.get('book_id')
    user_id = request.session.get('user_id')
    if request.method == 'POST':
        score = request.POST.get('score')
        if score.isdecimal():
            score_record = Book_score.objects.filter(book_id=book_id).filter(user_id=user_id)
            if not score_record.exists():
                book_score = Book_score()
                book_score.book_id = book_id
                book_score.user_id = user_id
                book_score.score = decimal.Decimal(score)
                book_score.save()
            else:
                book_score = score_record.first()
                book_score.score = score
                book_score.save()
            book = Book.objects.get(pk=book_id)
            dict = Book_score.objects.filter(book_id=book_id).aggregate(Avg('score'))
            book.b_score = dict['score__avg']
            book.save()
    return redirect(reverse('web:one_book', args={book_id}))


def deal_comment(request):
    user_id = request.session.get('user_id')
    comment_id = request.GET.get('commentid')
    type = request.GET.get('type')
    comment = Book_comment.objects.get(pk=comment_id)
    if type == 'like':
        unlike = comment.user_unlike.filter(id=user_id).first()
        if unlike:
            comment.user_unlike.remove(unlike)
            comment.disagree_num = comment.disagree_num - 1
        comment.user_like.add(user_id)
        comment.agree_num = comment.agree_num + 1
    elif type == 'dislike':
        like = comment.user_like.filter(id=user_id).first()
        if like:
            comment.user_like.remove(like)
            comment.agree_num = comment.agree_num - 1
        comment.user_unlike.add(user_id)
        comment.disagree_num = comment.disagree_num + 1
    comment.save()
    data = {
        'status': 200,
        'msg': 'ok',
    }
    return JsonResponse(data=data)


def delete_comment(request):
    comment_id = request.GET.get('commentid')
    comment = Book_comment.objects.get(pk=comment_id)
    if comment:
        comment.delete()
    data = {
        'ststus': 200,
        'msg': 'delete ok',
    }
    return JsonResponse(data=data)


def comment(request):
    user_id = request.session.get('user_id')
    book_id = request.GET.get('book_id')
    if user_id:
        if request.method == 'POST':
            comment = Book_comment()
            comment.book_id = book_id
            comment.user_id = user_id
            comment.title = request.POST.get('title')
            comment.content = request.POST.get('content')
            comment.save()
    else:
        return redirect(reverse('web:login'))

    return redirect(reverse('web:one_book', args={book_id}))


def deal_tip(request):
    data = {'title': '举报处理'}
    if not request.user.is_manager:
        return redirect(reverse('web:main'))
    tips = Book_comment_tip.objects.all()
    data['tips'] = tips
    return render(request, 'manager/dealtip.html', context=data)


def g_comment(request):
    data = {"msg": 200}
    comment_id = request.GET.get('comment_id')
    type = request.GET.get('type')
    comment = Group_comment.objects.get(pk=comment_id)
    if type == 'essential':
        comment.is_essential = not comment.is_essential
        comment.save()
    elif type == 'top':
        comment.is_top = not comment.is_top
        comment.save()
    elif type == 'delete':
        comment.delete()
    return JsonResponse(data=data)


def quit_group(request):
    group_id = request.GET.get('group_id')
    user_id = request.session.get('user_id')
    comments = Group_comment.objects.filter(user_id=user_id).filter(group_id=group_id)
    comments.delete()
    relation = Group_relations.objects.filter(g_user_id=user_id).filter(g_group_id=group_id)
    relation.delete()
    return redirect(reverse('web:one_group', args={group_id}))
