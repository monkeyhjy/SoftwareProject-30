from django.db import models

# Create your models here.
from django.db.models import CASCADE

# 用户
from django.utils import timezone


class User(models.Model):
    u_username = models.CharField(max_length=32, unique=True)
    u_password = models.CharField(max_length=256)
    u_email = models.CharField(max_length=64, unique=True)
    u_icon = models.ImageField(upload_to='icons/%Y/%m/%d/')
    # 用户是否激活
    is_active = models.BooleanField(default=False)
    # 用户是否删除
    is_delete = models.BooleanField(default=False)
    # 用户是否是系统管理员
    is_manager = models.BooleanField(default=False)

    class Meta:
        db_table = "user"


# 书籍
class Book(models.Model):
    b_book_name = models.CharField(max_length=64, unique=True)
    b_year = models.IntegerField()
    b_image = models.CharField(max_length=511)
    b_page_num = models.IntegerField()
    b_price = models.DecimalField(max_digits=5, decimal_places=2)
    b_author = models.CharField(max_length=32)
    b_book_describe = models.TextField()
    b_author_describe = models.TextField()
    b_tag = models.CharField(max_length=64)
    b_score = models.DecimalField(max_digits=3, decimal_places=1)
    # 书籍出版社
    b_publish = models.CharField(max_length=128)

    class Meta:
        db_table = "book"


# 小组
class Group(models.Model):
    g_id = models.CharField(max_length=64, unique=True)
    g_name = models.CharField(max_length=64)
    g_describe = models.TextField()
    g_num = models.IntegerField()

    class Meta:
        db_table = "group"


# 小组关系
class Group_relations(models.Model):
    g_user = models.ForeignKey(User, on_delete=CASCADE)
    g_group = models.ForeignKey(Group, on_delete=CASCADE)
    g_level = models.IntegerField(default=1)

    class Meta:
        db_table = "group_relation"


# 小组申请
class Add_group(models.Model):
    reason = models.TextField()
    g_user = models.ForeignKey(User, on_delete=CASCADE)
    g_group = models.ForeignKey(Group, on_delete=CASCADE)
    # 是否是申请成为管理员
    is_admin = models.BooleanField(default=False)

    class Meta:
        db_table = "add_group"


# 书籍评分
class Book_score(models.Model):
    book = models.ForeignKey(Book, on_delete=CASCADE)
    user = models.ForeignKey(User, on_delete=CASCADE)
    score = models.DecimalField(max_digits=3, decimal_places=1)

    class Meta:
        db_table = "book_score"


class Group_comment(models.Model):
    title = models.CharField(max_length=64)
    picture = models.ImageField(upload_to='pictures/%Y/%m/%d/',null=True,blank=True)
    content = models.TextField()
    is_top = models.BooleanField(default=False)
    is_essential = models.BooleanField(default=False)
    time = models.DateTimeField(default=timezone.now)
    group = models.ForeignKey(Group,on_delete=CASCADE)
    user = models.ForeignKey(User,on_delete=CASCADE)

    class Meta:
        db_table = "group_comment"
# 书籍评论
class Book_comment(models.Model):
    title = models.CharField(max_length=64)
    time = models.DateTimeField(default=timezone.now)
    book = models.ForeignKey(Book, on_delete=CASCADE)
    user = models.ForeignKey(User, on_delete=CASCADE)
    # 点赞数目
    agree_num = models.IntegerField(default=0)
    # 反对数目
    disagree_num = models.IntegerField(default=0)
    # 是否被举报
    is_report = models.BooleanField(default=False)
    content = models.TextField()
    user_like = models.ManyToManyField(User, related_name='user_like', blank=True)
    user_unlike = models.ManyToManyField(User, related_name='user_unlike', blank=True)

    class Meta:
        db_table = 'book_comment'


class Book_comment_tip(models.Model):
    title = models.CharField(max_length=64)
    reason = models.TextField()
    user = models.ForeignKey(User, on_delete=CASCADE)
    comment = models.ForeignKey(Book_comment, on_delete=CASCADE)

    class Meta:
        db_table = 'book_comment_tip'
