from django.urls import path, re_path

from Web import views

app_name = 'web'
# 网页路由
urlpatterns = [
    path('index/', views.index, name='index'),
    path('main/', views.main, name='main'),
    # 注册
    path('register/', views.register, name='register'),
    path('login/', views.login, name='login'),
    path('activate/', views.activate, name='activate'),
    # name重定向
    path('checkuser/', views.check_user, name='check_user'),
    path('logout/', views.logout, name='logout'),

    path('bookmainpage/', views.book_mainpage, name='book_mainpage'),

    path('moviemainpage/', views.movie_mainpage, name='movie_mainpage'),
    re_path('onebook/(?P<book_id>\d+)', views.only_one_book, name='one_book'),

    path('groupmainpage/', views.group_main_page, name='group_main_page'),
    re_path('onegroup/(?P<group_id>\d+)', views.only_one_group, name='one_group'),

    path('mygroup/', views.my_group, name='mygroup'),
    path('checkuser1/', views.check_user1, name='check_user'),

    path('groupsearch/', views.group_search, name='group_search'),
    re_path('groupdealrequest/(?P<group_id>\d+)', views.group_deal_request, name='group_deal_request'),

    path('addgroup/', views.add_group, name='add_group'),
    path('groupcreate/', views.group_create, name='group_create'),

    re_path('grouppost/(?P<group_id>\d+)', views.group_post, name='group_post'),
    path('checkgroup/', views.check_group, name='check_group'),

    path('booksearch/', views.book_search, name='book_search'),
    path('topicmainpage/', views.topic_main_page, name='topic_main_page'),

    path('booktip/', views.book_tip, name='book_tip'),
    path('bookscore/', views.book_score, name='book_score'),

    path('dealcomment/', views.deal_comment, name='deal_comment'),
    path('deletecomment/', views.delete_comment, name='delete_comment'),

    path('comment/', views.comment, name='comment'),
    path('dealtip/', views.deal_tip, name='deal_tip'),
    # 处理小组评论
    path('g_comment/',views.g_comment,name='g_comment'),
    path('quitgroup/',views.quit_group,name='quit_group'),
]
