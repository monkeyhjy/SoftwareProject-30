document.documentElement.style.fontSize = document.documentElement.clientWidth / 1347 * 12 + 'px';
console.log(document.documentElement.clientWidth);
// $("#main-top").load("/web/navigation");
// $("#footer").load("/web/footer");