// $(function () {
//     $("#search").click(function () {
//         $.post('/web/groupsearch/',
//             {
//                 "search_content": '1',
//                 "csrfmiddlewaretoken" : '{{ csrf_token }}'
//             },
//             function (data) {
//                 alert(data);
//             });
//         window.open('/web/mygroup/',target="_self");
//         alert('cao');
//     });
// });