function windowOn(window, button) {
    button.addEventListener('click', function () {
        window.style.display = 'block';
        maskbg.style.display = 'block';
    })
}
function close(window, close) {
    close.addEventListener('click', function () {
        window.style.display = 'none';
        maskbg.style.display = 'none';
    })
}
function windowOn(window, button) {
    button.addEventListener('click', function () {
        window.style.display = 'block';
        maskbg.style.display = 'block';
    })
}
function close(window, close) {
    close.addEventListener('click', function () {
        window.style.display = 'none';
        maskbg.style.display = 'none';
    })
}
var illegal = document.getElementById('illegal');
var illegalButton = document.getElementById('illegalButton');
var illegalClose = document.getElementById('illegalClose');
var illegalTitle = document.getElementById('illegalTitle');
var illegalText = document.getElementById('illegalText');
var illegalSubmit = document.getElementById('illegalSubmit');
var illegalWrong = document.getElementById('illegalWrong');
var maskbg = document.getElementById('maskbg');
windowOn(illegal, illegalButton);
close(illegal, illegalClose);
illegalSubmit.addEventListener('click', function (event) {
    if(illegalTitle.value.length === 0){
        illegalWrong.className = "wrongText";
        illegalWrong.innerHTML = '请输入举报标题';
        event.preventDefault();
    }
    else if(illegalText.value.length < 25){
        illegalWrong.className = "wrongText";
        illegalWrong.innerHTML = '举报理由不能少于15个字';
        event.preventDefault();
    }
})