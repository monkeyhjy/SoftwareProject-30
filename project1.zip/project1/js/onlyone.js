function windowOn(window, button) {
    button.addEventListener('click', function () {
        window.style.display = 'block';
        maskbg.style.display = 'block';
    })
}
function close(window, close) {
    close.addEventListener('click', function () {
        window.style.display = 'none';
        maskbg.style.display = 'none';
    })
}
var maskbg = document.getElementById('maskbg');
var score = document.getElementById('score');
var scoreButton = document.getElementById('scoreButton');
var scoreClose = document.getElementById('scoreClose');
var scoreNumber = document.getElementById('scoreNumber');
var scoreSubmit = document.getElementById('scoreSubmit');
var scoreWrong = document.getElementById('scoreWrong');
var review = document.getElementById('review');
var reviewButton = document.getElementById('reviewButton');
var reviewClose = document.getElementById('reviewClose');
var reviewTitle = document.getElementById('reviewTitle');
var reviewText = document.getElementById('reviewText');
var reviewSubmit = document.getElementById('reviewSubmit');
var reviewWrong = document.getElementById('reviewWrong');


windowOn(score, scoreButton);
close(score, scoreClose);
windowOn(review, reviewButton);
close(review, reviewClose);
scoreSubmit.addEventListener('click', function (event) {
    if(scoreNumber.value.length === 0 ){
        scoreWrong.className = "wrongText";
        scoreWrong.innerHTML = '请输入分数（1~10的整数，包括1和10）';
        event.preventDefault();
    }
    else if(scoreNumber < 1 || scoreNumber > 10){
        scoreWrong.className = "wrongText";
        scoreWrong.innerHTML = '请输入1~10内的数字';
        event.preventDefault();
    }
})
reviewSubmit.addEventListener('click', function (event) {
    if(reviewTitle.value.length === 0){
        reviewWrong.className = "wrongText";
        reviewWrong.innerHTML = '请输入评论标题';
        event.preventDefault();
    }
    else if(reviewText.value.length < 25){
        reviewWrong.className = "wrongText";
        reviewWrong.innerHTML = '评论内容不能少于25个字';
        event.preventDefault();
    }
})