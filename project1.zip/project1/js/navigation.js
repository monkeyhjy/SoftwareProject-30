
document.documentElement.style.fontSize =
    document.documentElement.clientWidth / 1347 * 12 + 'px';
