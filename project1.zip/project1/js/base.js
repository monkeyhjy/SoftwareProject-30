$("#main-top").load("navigation.html");
$("#footer").load("footer.html");
document.documentElement.style.fontSize =
    document.documentElement.clientWidth / 1347 * 12 + 'px';