function windowOn(window, button) {
    button.addEventListener('click', function () {
        window.style.display = 'block';
        maskbg.style.display = 'block';
    })
}
function close(window, close) {
    close.addEventListener('click', function () {
        window.style.display = 'none';
        maskbg.style.display = 'none';
    })
}
var maskbg = document.getElementById('maskbg');
var groupJoin = document.getElementById('groupJoin');
var groupJoinLink = document.getElementById('groupJoinLink');
var groupJoinClose = document.getElementById('groupJoinClose');
windowOn(groupJoin, groupJoinLink);
close(groupJoin, groupJoinClose);
