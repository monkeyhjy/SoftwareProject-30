addEventListener("load", function() {
    setTimeout(hideURLbar, 0);
}, false);

function hideURLbar() {
    window.scrollTo(0, 1);
}
var	user = document.getElementById('username');
var email = document.getElementById('email');
var pwd = document.getElementById('password');
var wrong = document.getElementById('wrong');
var eyeFlag = 0;
var btn = document.getElementById('submit');
var regx = /^(?!([a-zA-Z]+|\d+)$)[a-zA-Z\d]{6,16}$/;
var emregx = /^\w{3,}(\.\w+)*@[A-z0-9]+(\.[A-z]{2,5}){1,2}$/;
var eye = document.getElementById('eye');
var pwd2 = document.getElementById('password2');
var eye2 = document.getElementById('eye2');
var eyeFlag2 = 0;

function eyeDisplay(eye, eyeFlag, pwd){
    eye.addEventListener('click', function () {
        if(eyeFlag === 0){
            pwd.type = 'text';
            eyeFlag = 1;
            eye.className = "glyphicon glyphicon-eye-open";
        }
        else{
            pwd.type = 'password';
            eyeFlag = 0;
            eye.className = "glyphicon glyphicon-eye-close";
        }
    })
}

btn.addEventListener('click', function (event) {
    if(user.value.length === 0 ){
        wrong.className = "wrongText";
        wrong.innerHTML = '请输入用户名';
        event.preventDefault();
    }
    else if(user.value.length > 10){
        wrong.className = "wrongText";
        wrong.innerHTML = '用户名不得超过10个字符';
        event.preventDefault();
    }
    else if(email.value.match(emregx) == null){
        wrong.className = "wrongText";
        wrong.innerHTML = '请输入正确的邮箱地址';
        event.preventDefault();
    }
    else if(pwd.value.length < 6 || pwd.value.length > 16 ||
        pwd.value.match(regx) == null){
        wrong.className = "wrongText";
        wrong.innerHTML = '密码长度必须为6~16位，且必须包含数字和字母';
        event.preventDefault();
    }
    else if(pwd.value.toString() !== pwd2.value.toString()){
        wrong.className = "wrongText";
        wrong.innerHTML = '两次输入的密码不一致';
        event.preventDefault();
    }
})

eyeDisplay(eye, eyeFlag, pwd);
eyeDisplay(eye2, eyeFlag2, pwd2);
document.documentElement.style.fontSize =
    document.documentElement.clientWidth / 1347 * 12 + 'px';